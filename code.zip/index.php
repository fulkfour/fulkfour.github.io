<?php
header("Content-type: text/html; charset=utf-8");
include "TopSdk.php";
//将下载SDK解压后top里的TopClient.php第8行$gatewayUrl的值改为沙箱地址:http://gw.api.tbsandbox.com/router/rest,
//正式环境时需要将该地址设置为:http://gw.api.taobao.com/router/rest
 
//实例化TopClient类
	
//echo $_GET['top_session'];

	
$c = new TopClient;
$c->appkey = "21784702";
$c->secretKey = "0f68d907564d822319d843e43fa8de26";
$sessionkey= $_GET['top_session'];//如沙箱测试帐号sandbox_c_1授权后得到的sessionkey




//实例化具体API对应的Request类
//$req = new UserSellerGetRequest;
//$req->setFields("nick,user_id,sex,seller_credit,type,has_more_pic,item_img_num,item_img_size,prop_img_num,prop_img_size,auto_repost,promoted_type,status,alipay_bind,consumer_protection,avatar,liangpin,sign_food_seller_promise,has_shop,is_lightning_consignment,has_sub_stock,is_golden_seller,vip_info,magazine_subscribe,vertical_market,online_gaming");
//$req->setNick("sandbox_c_1");



//$req = new ItemGetRequest;
//$req->setFields("title");
//$req->setNumIid(26980888200);



//$req = new ItemsInventoryGetRequest;
//$req->setFields("pic_url,num");



$req = new ItemQuantityUpdateRequest;
$req->setNumIid(26980888200);
//$req->setSkuId(1230005);
//$req->setOuterId("1234");
$req->setQuantity(2);

//$req->setNick("sandbox_c_1");


 
//执行API请求并打印结果
$resp = $c->execute($req,$sessionkey);


echo "result:";
print_r($resp);


?>